// فایل سرویس ورکر برای السوق المفتوح + ایران
const cacheName = 'souq-v1';
const staticAssets = [
  './',
  './index.html',
  './manifest.json',
  './icon.png'
];

self.addEventListener('install', async el => {
  const cache = await caches.open(cacheName);
  await cache.addAll(staticAssets);
});

self.addEventListener('fetch', async el => {
  const req = el.request;
  const url = new URL(req.url);

  if (url.origin === location.origin) {
    el.respondWith(cacheFirst(req));
  } else {
    el.respondWith(networkAndCache(req));
  }
});

async function cacheFirst(req) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(req);
  return cached || fetch(req);
}

async function networkAndCache(req) {
  const cache = await caches.open(cacheName);
  try {
    const refresh = await fetch(req);
    await cache.put(req, refresh.clone());
    return refresh;
  } catch (e) {
    const cached = await cache.match(req);
    return cached;
  }
}